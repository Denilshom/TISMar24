<?php

namespace Cinema;

use Illuminate\Database\Eloquent\Model;

class Subarea extends Model
{
    protected $table = 'subareas';

    protected $fillable = ['subarea'];
}
