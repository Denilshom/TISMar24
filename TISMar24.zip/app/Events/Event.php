<?php

namespace Cinema\Events;

abstract class Event
{
    //
}
