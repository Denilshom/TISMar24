<div class="form-group">
 {!!Form:: label ('Codigo')!!}
 {!!Form::text('code',null, ['class'=>'form-control', 'placeholder'=>'Ingresar codigo'])!!}
</div>
<div class="form-group">
		{!!Form::label('Modalidad')!!}
		{!!Form::text('namemodal',null,['class'=>'form-control','placeholder'=>'Ingresa el Nombre de la modalidad'])!!}
</div>