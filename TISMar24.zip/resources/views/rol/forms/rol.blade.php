<div class="form-group">
	{!!Form::label('nameRol','Nombre de Rol: ')!!}
	{!!Form::text('nameRol',null, ['id'=>'nameRol','class'=>'form-control', 'placeholder' => 'Ingresa el nombre del rol'])!!}
</div>
